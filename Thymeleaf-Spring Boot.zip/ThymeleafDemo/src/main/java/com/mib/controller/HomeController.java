package com.mib.controller;

public class HomeController {
}
